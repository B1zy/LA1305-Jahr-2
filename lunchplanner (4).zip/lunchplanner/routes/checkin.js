const express = require('express');
const CheckIn = require('../models/CheckIn');
const router = express.Router();
const jwt = require('jsonwebtoken');

// Middleware to verify and set userId
router.use((req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ message: 'No token provided' });
  }

  jwt.verify(token.split(' ')[1], process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Failed to authenticate token' });
    }
    req.userId = decoded.userId;
    next();
  });
});

router.post('/', async (req, res) => {
  const { lunchSpotId, date } = req.body;
  const userId = req.userId;

  if (!userId || !lunchSpotId || !date) {
    console.log('Missing fields:', { userId, lunchSpotId, date });
    return res.status(400).json({ message: 'Please provide userId, lunchSpotId, and date' });
  }

  const checkIn = new CheckIn({ userId, lunchSpotId, date });
  try {
    await checkIn.save();
    res.status(201).json({ message: 'Checked in' });
  } catch (error) {
    console.error('Error checking in', error);
    res.status(400).json({ message: error.message });
  }
});

router.get('/', async (req, res) => {
  const { userId, date } = req.query;
  try {
    const checkIns = await CheckIn.find({ userId, date });
    res.json(checkIns);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
