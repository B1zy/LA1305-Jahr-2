const express = require('express');
const LunchSpot = require('../models/LunchSpot');
const router = express.Router();

router.get('/', async (req, res) => {
  const spots = await LunchSpot.find();
  res.send(spots);
});

router.post('/', async (req, res) => {
  const spot = new LunchSpot(req.body);
  try {
    await spot.save();
    res.status(201).send('Lunch spot created');
  } catch (error) {
    res.status(400).send(error.message);
  }
});

module.exports = router;
