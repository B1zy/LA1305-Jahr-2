const mongoose = require('mongoose');
const dotenv = require('dotenv');
const LunchSpot = require('./models/LunchSpot');

dotenv.config();

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const lunchSpots = [
  { name: 'Cafeteria', location: 'Building A', description: 'The main cafeteria' },
  { name: 'Football Field', location: 'Sports Complex', description: 'The open football field' },
  { name: 'Library Café', location: 'Library', description: 'Café in the library' },
  { name: 'Garden', location: 'Central Garden', description: 'The garden area' },
  { name: 'Rooftop', location: 'Building B', description: 'The rooftop café' },
];

const seedLunchSpots = async () => {
  try {
    await LunchSpot.deleteMany({});
    await LunchSpot.insertMany(lunchSpots);
    console.log('Lunch spots seeded!');
    mongoose.connection.close();
  } catch (error) {
    console.error('Error seeding lunch spots:', error);
  }
};

seedLunchSpots();
