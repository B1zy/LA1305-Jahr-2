const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');  // Importieren Sie das CORS-Modul

dotenv.config();

const authRoutes = require('./routes/auth');
const lunchSpotRoutes = require('./routes/lunchspot');
const checkInRoutes = require('./routes/checkin');

const app = express();

app.use(cors());  // Aktivieren Sie CORS

mongoose.connect(process.env.MONGO_URI);

app.use(bodyParser.json());

app.use('/auth', authRoutes);
app.use('/lunchspots', lunchSpotRoutes);
app.use('/checkin', checkInRoutes);

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
