const mongoose = require('mongoose');

const lunchSpotSchema = new mongoose.Schema({
  name: { type: String, required: true },
  location: { type: String, required: true },
  description: { type: String }
});

module.exports = mongoose.model('LunchSpot', lunchSpotSchema);
