const mongoose = require('mongoose');

const checkInSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' },
  lunchSpotId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'LunchSpot' },
  date: { type: Date, required: true }
});

module.exports = mongoose.model('CheckIn', checkInSchema);
