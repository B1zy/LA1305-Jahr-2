document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login');
    const registerForm = document.getElementById('register');
    const checkinForm = document.getElementById('checkin');
    const loginFormContainer = document.getElementById('login-form');
    const registerFormContainer = document.getElementById('register-form');
    const contentContainer = document.getElementById('content');
    const lunchSpotsList = document.getElementById('lunch-spots');
    const checkinsList = document.getElementById('checkins');
    const spotSelect = document.getElementById('spot');
    const token = localStorage.getItem('token');

    const apiUrl = 'http://localhost:3001';

    if (token) {
        showContent();
    } else {
        showAuthForms();
    }

    function showAuthForms() {
        loginFormContainer.style.display = 'block';
        registerFormContainer.style.display = 'block';
        contentContainer.style.display = 'none';
    }

    function showContent() {
        loginFormContainer.style.display = 'none';
        registerFormContainer.style.display = 'none';
        contentContainer.style.display = 'block';
        loadLunchSpots();
        loadCheckIns();
    }

    async function loadLunchSpots() {
        try {
            const response = await fetch(`${apiUrl}/lunchspots`);
            const spots = await response.json();
            lunchSpotsList.innerHTML = '';
            spotSelect.innerHTML = '';
            spots.forEach(spot => {
                const li = document.createElement('li');
                li.textContent = `${spot.name} - ${spot.location}: ${spot.description}`;
                lunchSpotsList.appendChild(li);

                const option = document.createElement('option');
                option.value = spot._id;
                option.textContent = spot.name;
                spotSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Error loading lunch spots:', error);
        }
    }

    async function loadCheckIns() {
        try {
            const response = await fetch(`${apiUrl}/checkin`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            const checkins = await response.json();
            checkinsList.innerHTML = '';
            checkins.forEach(checkin => {
                const li = document.createElement('li');
                li.textContent = `Spot: ${checkin.lunchSpotId} - Date: ${checkin.date}`;
                checkinsList.appendChild(li);
            });
        } catch (error) {
            console.error('Error loading check-ins:', error);
        }
    }

    loginForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        const formData = new FormData(loginForm);
        const data = {
            username: formData.get('username'),
            password: formData.get('password')
        };
        try {
            const response = await fetch(`${apiUrl}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            if (result.token) {
                localStorage.setItem('token', result.token);
                console.log('User ID:', result.userId); // Log the user ID
                showContent();
            } else {
                console.error('Login failed');
            }
        } catch (error) {
            console.error('Login error:', error);
        }
    });

    registerForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        const formData = new FormData(registerForm);
        const data = {
            username: formData.get('username'),
            password: formData.get('password'),
            email: formData.get('email')
        };
        console.log('Sending registration data', data);
        try {
            const response = await fetch(`${apiUrl}/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            if (response.status === 201) {
                console.log('User registered successfully');
            } else {
                const errorData = await response.json();
                console.error('Registration failed', errorData);
            }
        } catch (error) {
            console.error('Registration error:', error);
        }
    });

    checkinForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        const lunchSpotId = spotSelect.value; // Direkt aus dem select-Feld
        const date = document.getElementById('date').value; // Direkt aus dem date-Feld
        const data = {
            lunchSpotId: lunchSpotId,
            date: date
        };
        console.log('Sending check-in data', data);
        try {
            const response = await fetch(`${apiUrl}/checkin`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(data)
            });

            // Überprüfen Sie den Status der Antwort
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText);
            }

            const result = await response.json();
            if (response.status === 201) {
                loadCheckIns();
                console.log('Checked in successfully');
            } else {
                console.error('Check-in failed', result);
            }
        } catch (error) {
            console.error('Check-in error:', error.message);
        }
    });
});
